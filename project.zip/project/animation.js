$(function(){
	/*$("div").toggle();
$("div").slideDown(4000);*/
/*$(".but").slideUp(4000);
$(".but").slideDown(4000);*/
$("img").fadeOut(200);
$("img").fadeIn(200);
$("body").fadeOut(200);
$("body").fadeIn(200);
$("img").fadeOut(200);
$(".form").fadeOut().slideDown(2000);
$(".form").fadeIn(2000);
	$("h1").slideDown(200);
});
/*$("h1").mouseover(function(){
	$("h1").slideUp(500);
})
*/


