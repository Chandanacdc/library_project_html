$(function(){
	$("p").css("background-color","red");
	$("li:first").css("background-color","red");
	$("input").css("background-color","blue");
	$("#list").css("background-color","yellow");
	/*$("p:first").css("background-color","yellow");*/
	$("p:odd").css("background-color","yellow");
	/*$("h1,p,input").css("background-color","yellow");*/
	/*$("#pt").css("background-color","yellow");*/
	/*$("textarea").css("background-color","blue");*/

});